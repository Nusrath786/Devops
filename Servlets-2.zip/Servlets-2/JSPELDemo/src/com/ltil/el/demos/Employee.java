package com.ltil.el.demos;

public class Employee {
	int empId;
	String empName;
	double empsal;
	Vehicle v;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpsal() {
		return empsal;
	}
	public void setEmpsal(double empsal) {
		this.empsal = empsal;
	}
	public Vehicle getV() {
		return v;
	}
	public void setV(Vehicle v) {
		this.v = v;
	}
	public Employee(int empId, String empName, double empsal, Vehicle v) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empsal = empsal;
		this.v = v;
	}
	public Employee() {
		super();
		
	}

}
