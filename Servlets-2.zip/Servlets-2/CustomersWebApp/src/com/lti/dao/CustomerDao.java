package com.lti.dao;
import com.lti.bean.*;
import java.util.*;
public interface CustomerDao {
	
	public List<Customer> getAllCustomers();

}
