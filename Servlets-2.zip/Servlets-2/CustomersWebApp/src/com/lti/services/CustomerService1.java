package com.lti.services;

import java.sql.SQLException;
import java.util.List;

import com.lti.bean.Customer;
import com.lti.dao.CustomerDao;

public interface CustomerService1 {
	
	
	public List<Customer> getAllCustomers() ;
	
}
