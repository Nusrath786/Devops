package com.lti.employee;

public class Employee {

}
